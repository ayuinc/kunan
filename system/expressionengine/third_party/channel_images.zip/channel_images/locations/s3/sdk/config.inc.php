<?php if (!class_exists('CFRuntime')) die('No direct access allowed.');
