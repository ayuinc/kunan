<?php echo $this->view('mcp/menu'); ?>
