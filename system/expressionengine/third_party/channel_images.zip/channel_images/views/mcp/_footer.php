<div class="utable" id="ci_ajax_error">
<h2>AJAX Error</h2>
<iframe src="about:blank"></iframe>
</div>

<br clear="all">
</div> <!-- #cimcp -->
