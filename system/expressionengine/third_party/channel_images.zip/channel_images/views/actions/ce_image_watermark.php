<?php $thstyle='style="border-right-color:rgba(0, 0, 0, 0.1); border-right-style:solid; border-right-width:1px;"';?>
<table cellspacing="0" cellpadding="0" border="0" class="ChannelImagesTable CITable">
	<thead>
		<tr>
			<th>Parameter</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>
				<?=form_input($action_field_name.'[param]', $param, 'style="border:1px solid #ccc; width:80%;"')?>
				<br>Paramater Documentation can be found at: <a href="http://www.causingeffect.com/software/expressionengine/ce-image/user-guide/parameters#watermark" target="_blank">http://www.causingeffect.com/software/expressionengine/ce-image/user-guide/parameters#watermark</a>
			</td>
		</tr>
	</tbody>
</table>

