<script type="text/javascript">
ChannelImages.LANG = <?=$langjson?>;
</script>

